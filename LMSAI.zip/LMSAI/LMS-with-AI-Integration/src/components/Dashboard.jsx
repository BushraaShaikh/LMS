const Dashboard = () => {
    return (
      <div className="container">
        <h2>Welcome to the LMS Dashboard</h2>
        <p>Here you can access your courses, assignments, and AI-based recommendations.</p>
      </div>
    );
  };
  
  export default Dashboard;
  