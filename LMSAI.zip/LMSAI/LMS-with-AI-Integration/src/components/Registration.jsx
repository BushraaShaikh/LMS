import { useState } from "react";

const Registration = () => {
  const [course, setCourse] = useState("");

  const handleRegister = (e) => {
    e.preventDefault();
    alert(`You have registered for ${course}`);
  };

  return (
    <div className="container">
      <h2>Course Registration</h2>
      <form onSubmit={handleRegister}>
        <input
          type="text"
          placeholder="Course Name"
          required
          onChange={(e) => setCourse(e.target.value)}
        />
        <button type="submit">Register</button>
      </form>
    </div>
  );
};

export default Registration;
